-- | An example module.
module Example (main) where

-- | An example function.
main :: IO ()
main = return ()
